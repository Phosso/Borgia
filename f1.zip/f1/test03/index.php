
<html lang="en">
<head>

	<title>Test</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
   <header>
   	 <div class="container">
   	 	<h1>Тест на знания</h1>
   	 </div>
   </header>

   <main>
   	<div class="menu">

   	<a href="main.php" class="button">Пройти тест</a>
   	<a href="add.php" class="button">Добавить новый тест</a>
   	</div>
   </main>

  <footer>
			<div class="container">
				Copyright &copy; Исторический архив
			</div>


	</footer>
</body>
</html>